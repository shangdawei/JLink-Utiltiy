This example shows:

- use of WinHelper unit
- how to enumerate processes
- how to enumerate process modules
- how to load image from running process
- how to get process id from process name